<a href="{{ route('admin.employees.create') }}"
    class="inline-flex items-center px-4 py-2 rounded-xl border bg-gray-900 text-white text-sm">
    Add Employee
</a>
