<a href="<?php echo e(route('admin.employees.create')); ?>"
    class="inline-flex items-center px-4 py-2 rounded-xl border bg-gray-900 text-white text-sm">
    Add Employee
</a>
<?php /**PATH E:\Laravel Applications\siatex-docs\resources\views/admin/employees/partials/create-btn.blade.php ENDPATH**/ ?>