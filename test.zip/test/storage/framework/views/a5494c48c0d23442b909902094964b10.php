<?php if(auth()->user()->isSuperAdmin()): ?>
    <a href="<?php echo e(route('admin.users.create')); ?>"
        class="inline-flex items-center px-4 py-2 rounded-xl border bg-gray-900 text-white text-sm">
        Register Admin
    </a>
<?php endif; ?>
<?php /**PATH E:\Laravel Applications\siatex-docs\resources\views/admin/partials/register-btn.blade.php ENDPATH**/ ?>