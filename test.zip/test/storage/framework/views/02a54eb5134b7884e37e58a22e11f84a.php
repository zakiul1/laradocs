<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => null,
    'action' => null,
    'footer' => null, // keep prop support if you used it elsewhere
    'bodyClass' => null,
    'stickyHeader' => false,
    'stickyFooter' => false,
    'scrollBody' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => null,
    'action' => null,
    'footer' => null, // keep prop support if you used it elsewhere
    'bodyClass' => null,
    'stickyHeader' => false,
    'stickyFooter' => false,
    'scrollBody' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div <?php echo e($attributes->merge(['class' => 'rounded-2xl border bg-white shadow-sm'])); ?>>
    <?php if($title || $action): ?>
        <div class="<?php echo e($stickyHeader ? 'sticky top-0 z-10' : ''); ?> px-6 py-4 border-b bg-white/90 backdrop-blur">
            <div class="flex items-center justify-between gap-4">
                <?php if($title): ?>
                    <h2 class="text-base font-semibold"><?php echo e($title); ?></h2>
                <?php endif; ?>
                <?php if($action): ?>
                    <div><?php echo e($action); ?></div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    <div class="<?php echo e($bodyClass ?? 'p-6'); ?> <?php if($scrollBody): ?> overflow-y-auto <?php endif; ?>">
        <?php echo e($slot); ?>

    </div>

    
    <?php if(isset($footer)): ?>
        <div class="<?php echo e($stickyFooter ? 'sticky bottom-0 z-10' : ''); ?> px-6 py-4 border-t bg-white/90 backdrop-blur">
            <?php echo e($footer); ?>

        </div>
    <?php elseif(!empty($footer)): ?>
        <div class="<?php echo e($stickyFooter ? 'sticky bottom-0 z-10' : ''); ?> px-6 py-4 border-t bg-white/90 backdrop-blur">
            <?php echo $footer; ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH E:\Laravel Applications\siatex-docs\resources\views/components/card.blade.php ENDPATH**/ ?>