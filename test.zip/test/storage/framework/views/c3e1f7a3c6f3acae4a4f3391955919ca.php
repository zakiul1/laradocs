<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'id' => null,
    'type' => 'text',
    'name',
    'value' => '',
    'placeholder' => '',
    'required' => false,
    'autocomplete' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'id' => null,
    'type' => 'text',
    'name',
    'value' => '',
    'placeholder' => '',
    'required' => false,
    'autocomplete' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<input id="<?php echo e($id ?? $name); ?>" name="<?php echo e($name); ?>" type="<?php echo e($type); ?>" value="<?php echo e(old($name, $value)); ?>"
    placeholder="<?php echo e($placeholder); ?>" <?php if($required): ?> required <?php endif; ?>
    <?php if($autocomplete): ?> autocomplete="<?php echo e($autocomplete); ?>" <?php endif; ?>
    <?php echo e($attributes->merge(['class' => 'bg-[#f2f8fd] text-gray-900 focus:border-[#c2e0f5] focus:bg-white autofill:bg-white w-full rounded-lg  focus:ring-0'])); ?> />
<?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php /**PATH E:\Laravel Applications\siatex-docs\resources\views/components/input.blade.php ENDPATH**/ ?>